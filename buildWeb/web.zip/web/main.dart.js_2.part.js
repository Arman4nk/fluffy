((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_2",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,A={aM:function aM(){}}
B=c[0]
A=a.updateHolder(c[54],A)
A.aM.prototype={
B(d,e){return this.gba(this).$1(e)}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.aM,B.F)})()};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_2",e:"endPart",h:b})})($__dart_deferred_initializers__,"8YI1d9LbCwifR0m1f+/egtKGUHA=");